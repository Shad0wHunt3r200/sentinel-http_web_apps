const express = require('express')

const utils = require('./utils')
const userData = require('./data')

const router = express.Router()

router.get("/login", (req, res) => {
  // Your code here
})

module.exports = router;