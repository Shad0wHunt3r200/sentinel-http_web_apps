const express = require('express');

const router = express.Router();

// Simplest parameterized view
router.get("/", (req, res) => {
  res.render("index", { title: "Hello!!!!!" })
})

module.exports = router;