const fs = require('fs')

function readUserData() {
  // YOUR CODE HERE.
  // Read and parse the store.json file, and return the array inside.
}

module.exports = { readUserData }